"use client"
import { useState, useEffect } from "react";
import Loading from "@/components/section/Loading";
import Header from "@/components/section/Header";
import { Fingerprint } from "@/components/animate-ui/icons/fingerprint";
import HeroSection from "@/components/section/Hero";
import About from "@/components/section/About";
import ReportFormCard from "@/components/section/ReportForm";
import ContactCard from "@/components/section/Contact";
import Footer from "@/components/section/Footer";
import ScrollVelocity from "@/components/layout/ScrollVelocity";
import Aurora from "@/components/layout/Aurora";

export default function Home() {
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const timer = setTimeout(() => setLoading(false), 2000);
    return () => clearTimeout(timer);
  }, []);

  const navLinks = [
    { name: "Focus Area", href: "#focus", type: "hash" },
    { name: "Discoveries", href: "/discoveries", type: "href" },
    { name: "Report", href: "#report", type: "hash" },
    { name: "Contact", href: "#contact", type: "hash" },
  ];

  if (loading) {
    return (
      <Loading />
    );
  }

  return (
    <div className="relative min-h-screen overflow-hidden">
      <div className="fixed inset-0 -z-50 bg-black pointer-events-none" aria-hidden="true">
        <Aurora
          colorStops={["#3A29FF", "#FF94B4", "#FF3232"]}
          blend={0.5}
          amplitude={1.0}
          speed={0.5}
        />
      </div>

      <Header
        logo={
          <div className="flex items-center gap-2 text-white font-semibold">
            <Fingerprint animateOnHover /> Safetronix
          </div>
        }
        links={navLinks}
      />
      <HeroSection />
      <About />

      <section className="px-4 py-12 bg-transparent mt-[7rem]">
        <div className="flex justify-center">
          <ScrollVelocity
            texts={["Real-Time Harm Detection   Rapid Content Escalation   Zero Tolerance Reporting", "24/7 Threat Monitoring   AI-Powered Abuse Defense   Built for Enforcement Agencies"]}
            velocity={50}
            className="text-white"
          />
        </div>
      </section>
      <section className="px-4 py-12 bg-transparent mt-[7rem]">
        <div className="flex flex-col lg:flex-row justify-center items-start gap-8 w-full max-w-7xl mx-auto">
          <div className="flex-1 min-w-[300px]">
            <ReportFormCard />
          </div>
          <div className="flex-1 min-w-[300px]">
            <ContactCard />
          </div>
        </div>
      </section>
      <Footer />
    </div>
  );
}
